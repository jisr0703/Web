function signup_check(){
    var signupId=document.getElementById("signup_id").value;
    var signupPw=document.getElementById("signup_pw").value;
    var signupRePw=document.getElementById("signup_repw").value;
    var signupName=document.getElementById("signup_name").value;
    var signupTel=document.getElementById("signup_tel").value;

    if(signupId!=""){
        if(signupPw!=""){
            if(signupRePw!=""){
                if(signupPw==signupRePw){    
                    if(signupName!=""){
                        if(signupTel!=""){
                            alert("회원가입 완료!");
                        }
                        else{
                            alert("전화번호를 입력해주세요.");
                        }
                    }
                    else{
                        alert("이름을 입력해주세요.");
                    }
                }
                else{
                    alert("확인 비밀번호를 비밀번호와 같게 입력해주세요.");
                }
            }
            else{
                alert("확인할 비밀번호를 입력해주세요.");
            }
        }
        else{
            alert("비밀번호를 입력해주세요.");
        }
    }
    else{
        alert("아이디를 입력해주세요.");
    }
}